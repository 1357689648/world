import os


def get_path():
    path = os.path.split(os.path.realpath(__file__))[0][:-12]
    return path


# 执行该文件，测试下是否OK
if __name__ == '__main__':
    print('测试路径是否OK,路径为：', get_path())
