# coding=utf-8
# author_="bruce.gao"
# date:2019/10/8 17:02

import pymysql
from common.utils.read_config import ReadConfig
from common.base.config_log import Log


class GetMySql(object):
    def __init__(self):
        self.config = ReadConfig()
        self.logger = Log().run()
        self.host = self.config.get_mysql('host')
        self.port = int(self.config.get_mysql('port'))
        self.user = self.config.get_mysql('user')
        self.password = self.config.get_mysql('passwd')
        self.database = self.config.get_mysql('database')

    def connect(self):
        try:
            self.db = pymysql.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database,
                charset='utf8',

            )
            self.logger.info('连接数据库成功')
        except Exception as error:
            self.logger.error('连接数据库失败！！！！')
            self.logger.error(error)
        else:
            self.cursor = self.db.cursor()
            self.logger.info('成功创建数据库游标')

    def close(self):
        try:
            self.db.close()
            self.cursor.close()
            self.logger.info('数据库连接关闭')
        except Exception as error:
            self.logger.error('数据库连接关闭失败！！！！')
            self.logger.error(error)

    def select(self, sql):
        my_result = ''
        try:
            self.cursor.execute(sql)
            my_result = self.cursor.fetchall()
        except Exception as error:
            self.logger.error('查询失败')
            self.logger.error(error)
        return my_result

    def insert(self, sql):
        # 兼容多条sql，分号分割循环执行
        sql = sql.split(';')
        for split_sql in sql:
            if split_sql != '':
                try:
                    self.cursor.execute(split_sql)
                    self.db.commit()
                    self.logger.info(split_sql + '执行成功')
                except Exception as error:
                    self.db.rollback()
                    self.logger.error('sql执行失败')
                    self.logger.error(error)

    def update(self, sql):
        # 兼容多条sql，分号分割循环执行
        sql = sql.split(';')
        for split_sql in sql:
            if split_sql != '':
                try:
                    self.cursor.execute(split_sql)
                    self.db.commit()
                    self.logger.info(split_sql + '执行成功')
                except Exception as error:
                    self.db.rollback()
                    self.logger.error(split_sql + ' 执行失败')
                    self.logger.error(error)

    def delete(self, sql):
        # 兼容多条sql，分号分割循环执行
        sql = sql.split(';')
        for split_sql in sql:
            if split_sql != '':
                try:
                    self.cursor.execute(split_sql)
                    self.db.commit()
                    self.logger.info(split_sql + '执行成功')
                except Exception as error:
                    self.db.rollback()
                    self.logger.error(split_sql + ' sql执行失败')
                    self.logger.error(error)

    def get_mysql(self):
        conn = pymysql.connect(
            host=self.host,
            port=int(self.port),
            user=self.user,
            password=self.password,
            database=self.database,
            charset='utf8')
        # cur = conn.cursor()
        # cur.execute("select uuid from task where title = '家里事任务流程_保存任务';")
        # data = cur.fetchall()
        return conn
        # cur.close()
        # conn.close()


if __name__ == '__main__':
    sql = "UPDATE `oms_product`.`product_archives` SET `status` = 1 WHERE spu_code like '%autojly%';UPDATE `oms_product`.`product_sku` SET `status` = 1 WHERE goods_code like '%autojly%';"
    db = GetMySql()
    db.connect()
    # result = db.select(sql)
    db.update(sql)
    db.close()
    # print(result)
