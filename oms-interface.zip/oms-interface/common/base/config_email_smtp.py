import smtplib
import os
from email.mime.text import MIMEText
from common.base import get_path_info
from common.utils.read_config import ReadConfig
from common.base.config_log import Log


class ConfigEmailSmtp(object):
    def __init__(self):
        self.path = get_path_info.get_path()
        self.report_path = os.path.join(self.path, 'report')

    def send_email(self):
        config = ReadConfig()
        logger = Log().run()
        # 邮件收发人、服务器等配置信息
        sender = config.get_email_smtp('sender')
        password = config.get_email_smtp('password')
        receiver = config.get_email_smtp('receiver')
        smtp_server = config.get_email_smtp('smtp_server')
        smtp_port = config.get_email_smtp('smtp_port')

        # 邮件主题
        mail_title = config.get_email_smtp('subject')

        # 获取最新的测试报告路径
        reports = os.listdir(self.report_path)
        reports.sort(key=lambda filename: os.path.getatime(os.path.join(self.report_path, filename)))
        last_report = reports[-1]
        last_report_dir = os.path.join(self.report_path, last_report)
        # print(last_report_dir)

        # 读取html文件内容
        f = open(last_report_dir, 'rb')
        mail_body = f.read()
        f.close()

        # 创建邮件
        message = MIMEText(mail_body, 'html', 'utf-8')
        message['From'] = sender
        message['To'] = receiver
        message['Subject'] = mail_title
        message["Content-Disposition"] = 'attachment; filename="report.html"'


        try:
            smtp = smtplib.SMTP()
            smtp.connect(smtp_server, smtp_port)
            smtp.login(sender, password)
            smtp.sendmail(sender, receiver.split(','), message.as_string())
            logger.info('发送邮件成功！！！')
            smtp.quit()
        except smtplib.SMTPException as error:
            logger.error(error)
            logger.info('邮件发送失败！！！')


if __name__ == '__main__':
    send_email = ConfigEmailSmtp()
    send_email.send_email()
