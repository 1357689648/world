# -*- coding: utf-8 -*-

'''
@Time    : 2021/6/9 17:40
@Author  : Jia Lu Yun
'''
from common.utils import read_config
from rediscluster import RedisCluster

config = read_config.ReadConfig()


class RedisHander(object):
    @staticmethod
    def conn_redis():
        host = config.get_redis('host')
        ports = config.get_redis('ports')
        password = config.get_redis('password')
        startup_nodes = []
        node = {}
        for port in ports.split(","):
            node["host"] = host
            node["port"] = port
            startup_nodes.append(node)
        rc = RedisCluster(startup_nodes=startup_nodes, decode_responses=True, password=password)
        return rc


if __name__ == '__main__':
    rc = RedisHander().conn_redis()
    value = rc.get("all_area_base")
    print(value)
    value = rc.hvals("opt_delivery_order")
    print(value)
    value = rc.hget("opt_delivery_order", "CK2106071401791533242888192")
    print(value)
    rc.delete("DATA_PRIVILEGE_EMP_ID:1284030236402962432")
    value = rc.hvals("DATA_PRIVILEGE_EMP_ID:1284030236402962432")
    print(value)
