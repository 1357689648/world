import requests
from common.base.config_log import Log
from common.utils import read_config

logger = Log().run()


class RunMain(object):

    def __init__(self):
        self.token = read_config.ReadConfig().get_header('token')
        self.employeeId = read_config.ReadConfig().get_header('employeeId')

    # 定义一个方法，传入需要的参数url和data
    def send_post(self, url, data):
        # 参数必须按照url、data顺序传入
        headers = {'Content-Type': 'application/json', 'token': self.token, 'employeeId': self.employeeId}
        # 因为这里要封装post方法，所以这里的url和data值不能写死
        result = requests.post(url=url, headers=headers, data=data)
        logger.debug('data:' + data.decode())
        return result

    def send_get(self, url, data):
        headers = {'token': self.token, 'employeeId': self.employeeId}
        result = requests.get(url=url, headers=headers, params=data)
        logger.debug('data:' + data.decode())
        return result

    # 定义一个run_main函数，通过传过来的method来进行不同的get或post请求
    def run_main(self, method, url=None, data=None):
        result = None
        if method == 'post':
            result = self.send_post(url, data)

        elif method == 'get':
            result = self.send_get(url, data)

        else:
            print("method值错误！！！")
            logger.info("method值错误！！！")
        return result


# 通过写死参数，来验证我们写的请求是否正确
if __name__ == '__main__':
    result = RunMain().run_main('get', 'http://192.168.1.198:10007/task/tasks', 'login_user=1342&page_num=1&page_size=10&status=0')
    print(result)
