# -*- coding: utf-8 -*-

'''
@Time    : 2021/6/11 14:24
@Author  : Jia Lu Yun
'''
from common.base.config_log import Log
import pika
import time
from common.utils.read_config import ReadConfig
logger = Log().run()
config = ReadConfig()


class MqHander(object):
    # 建立连接
    def __init__(self):
        host = config.get_rabbitmq('host')
        virtual_host = config.get_rabbitmq('virtual_host')
        port = config.get_rabbitmq('port')
        user = config.get_rabbitmq('user')
        password = config.get_rabbitmq('password')
        credentials = pika.PlainCredentials(user, password)
        params = pika.ConnectionParameters(host=host, port=port, virtual_host=virtual_host, credentials=credentials)
        connection = pika.BlockingConnection(parameters=params)
        self.channel = connection.channel()

    # 给mq发消息
    def publish_rabbitmq(self, exchange, routing_key, msg):
        try:
            self.channel.basic_publish(exchange=exchange, routing_key=routing_key, body=msg)
        except Exception as e:
            logger.debug("exchange: %s ,routing_key: %s " % (exchange, routing_key))
            logger.error(e)

    # 获取队列消息，nack
    def consumer_rabbitmq(self, queue):
        # 定义一个回调函数来处理消息队列中的消息，这里是打印出来
        def callback(ch, method, properties, body):
            now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            print('[%s] Recived: %r' % (now, body))

        # 告诉rabbitmq，用callback来接受消息，auto_ack=False，消息不确认，重回队列
        self.channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=False)
        self.channel.start_consuming()


if __name__ == '__main__':
    mq = MqHander()
    mq.publish_rabbitmq("test001", "test0010101", "python_publish3")
    # mq.consumer_rabbitmq("test00101")
