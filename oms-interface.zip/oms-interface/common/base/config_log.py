# -*- coding: utf-8 -*-
# 打印日志信息
"""
  ERROR：发生错误时，如IO操作失败或者连接问题
  WARNING：发生很重要的事件，但是并不是错误时，如用户登录密码错误
  INFO：处理请求或者状态变化等日常事务
  DEBUG：调试过程中使用DEBUG等级，如算法中每个循环的中间状态
"""
import logging
import logging.handlers
import time
import os
from common.base import get_path_info
from common.utils.read_config import ReadConfig

log_level = ReadConfig().get_log("level")


class Log(object):
    def __init__(self):
        self.logger = logging.getLogger()  # 添加日志器
        self.logger.setLevel(level=logging.DEBUG)  # 设置日志级别
        # 设置日志格式
        self.formatter1 = logging.Formatter(fmt="%(levelname)s :%(asctime)s - %(filename)s[%(lineno)d]:%(message)s", datefmt="%d-%m-%Y %H:%M:%S")
        self.formatter2 = logging.Formatter(fmt="%(levelname)s :%(asctime)s - %(filename)s[%(lineno)d] >>>>>>> %(message)s", datefmt="%d-%m-%Y %H:%M:%S")
        log_path = os.path.join(get_path_info.get_path(), 'log')
        self.log_name = os.path.join(log_path, '%s.log' % time.strftime('%y_%m_%d'))  # 日志文件名

    def add_StreamHandler(self):
        '''
        添加一个控制台处理器
        :return:
        '''
        self.hand=logging.StreamHandler()  # 添加控制台处理器
        # 设置处理器的日志级别
        if log_level == 'ERROR':
            self.hand.setLevel(level=logging.ERROR)
        if log_level == 'WARNING':
            self.hand.setLevel(level=logging.WARNING)
        if log_level == 'INFO':
            self.hand.setLevel(level=logging.INFO)
        if log_level == 'DEBUG':
            self.hand.setLevel(level=logging.DEBUG)
        self.hand.setFormatter(self.formatter1)   # 处理器添加格式
        self.logger.addHandler(self.hand)   # 日志器添加处理器

    def add_FileHandler(self):
        '''
        添加一个文件处理器
        :return:
        '''
        self.filehand = logging.FileHandler(filename=self.log_name, encoding='utf-8')  # 添加文件处理器
        # 设置处理器的日志级别
        if log_level == 'ERROR':
            self.filehand.setLevel(level=logging.ERROR)
        if log_level == 'WARNING':
            self.filehand.setLevel(level=logging.WARNING)
        if log_level == 'INFO':
            self.filehand.setLevel(level=logging.INFO)
        if log_level == 'DEBUG':
            self.filehand.setLevel(level=logging.DEBUG)
        self.filehand.setFormatter(self.formatter2)  # 处理器添加格式
        self.logger.addHandler(self.filehand)  # 日志器添加处理器

    def run(self):
        if not self.logger.handlers:  # 控制重复数据
            self.add_StreamHandler()
            self.add_FileHandler()
        return self.logger


if __name__ == '__main__':
    logger = Log().run()  # 实例化日志类，调用run方法
    logger.info("----------自动化测试开始----------")
    logger.info("登录成功...")
    logger.info('输入手势密码...')
    logger.warning("-----------自动化测试结束----------")
    logger.error("-----------error----------")
    logger.debug("-----------debug----------")

