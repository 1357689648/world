import os
from common.base import get_path_info
#调用读Excel的第三方库xlrd
from xlrd import open_workbook
# 拿到该项目所在的绝对路径
path = get_path_info.get_path()


class ReadExcel(object):
    # xls_name填写用例的Excel名称 sheet_name该Excel的sheet名称
    def get_xls(self, xls_name, sheet_name):
        cls = []
        # 获取用例文件路径
        xlsPath = os.path.join(path, "test_file", 'case', xls_name)
        # 打开用例Excel
        file = open_workbook(xlsPath)
        # 获得打开Excel的sheet
        sheet = file.sheet_by_name(sheet_name)
        # 获取这个sheet内容行数
        nrows = sheet.nrows
        # 根据行数做循环
        for i in range(nrows):
            # 如果这个Excel的这个sheet的第i行的第一列不等于case_name那么我们把这行的数据添加到cls[]
            if sheet.row_values(i)[0] != u'case_id':
                cls.append(sheet.row_values(i))
        return cls


# 我们执行该文件测试一下是否可以正确获取Excel中的值
if __name__ == '__main__':
    print(ReadExcel().get_xls('ops/baseData.xlsx', 'create'))
    print(ReadExcel().get_xls('ops/baseData.xlsx', 'create')[0][1])
    print(ReadExcel().get_xls('ops/baseData.xlsx', 'create')[1][2])
