# -*- coding: utf-8 -*-

'''
@Time    : 2021/2/26 17:54
@Author  : Jia Lu Yun
'''
import demjson
import jsonpath
from common.base.config_log import Log

logger = Log().run()


class AssertJson(object):
    def find_sort_key(self, llist):
        sort_key_set = llist[0].items() - llist[1].items()
        if len(llist) > 2:
            for i in range(2, len(llist)):
                sort_key_set = sort_key_set - llist[i].items()
        try:
            for sort_key in sort_key_set:
                break
            return str(sort_key[0])
        except Exception as err:
            logger.error(err)

    def sort_list1(self, llist):
        if len(llist)==1:
            return llist
        else:
            if type(llist[0]) == type({}):
                sort_key = self.find_sort_key(llist)
                llist.sort(key=lambda x: x[sort_key])
                for item in llist:
                    for key in item:
                        if type(item[key])==type([]):
                            item[key] = self.sort_list(item[key])
                return llist
            else:
                llist.sort()
                return llist

    def sort_list(self, list1, list2):
        if len(list1)==1:
            return list1, list2
        else:
            if type(list1[0]) == type({}):
                sort_key = self.find_sort_key(list1)
                list1.sort(key=lambda x: x[sort_key])
                list2.sort(key=lambda x: x[sort_key])
                for item in list1:
                    for key in item:
                        if type(item[key])==type([]):
                            item[key] = self.sort_list(item[key])
                for i in range(len(list1)):
                    for key in list1[i]:
                        if type(list1[i][key])==type([]):
                            list1[i][key], list2[i][key] = self.sort_list(list1[i][key], list2[i][key])
                return list1, list2
            else:
                list1.sort()
                return list1, list2

    # json串中包含list时，对list进行排序重新比较
    def assert_json_list(self, json1, json2):
        if json1 == json2:
            return True
        else:
            if len(json1) != len(json2):
                return False
            else:
                # for key in json1:
                #     if type(json1[key]) == type([]):
                #         json1[key], json2[key] = self.sort_list(json1[key], json2[key])
                json1 = self.ordered(json1)
                json2 = self.ordered(json2)
                if json1 == json2:
                    return True
                else:
                    return False

    def ordered(self, obj):
        if isinstance(obj, dict):
            return sorted((k, self.ordered(v)) for k, v in obj.items())
        if isinstance(obj, list):
            return sorted(self.ordered(x) for x in obj)
        else:
            return obj


if __name__ == '__main__':
    a = AssertJson()
    resp1 = {"record":'',"status":200,"message":"success","data":[{"sourceOrderId":"autojly20210044","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_011","combineCode":"autoops_zhz_goodscode_010","combineNum":1,"combineName":"普通件sku_有库存011","refundId":"","num":1,"price":2.0,"adjustFee":0.0,"discountFee":0.6,"shareDiscount":0.0,"sharePostFee":0.2,"totalFee":1.4,"payment":1.6,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":'',"actualNum":0,"totalGoodsFee":1.4,"shareAfterTotalFee":1.4,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_011","skuName":"普通件sku_有库存011","brandName":'',"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存011","barCode":"autoops_barcode_011","availableStock":''},{"sourceOrderId":"autojly20210044","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_011","combineCode":"","combineNum":0,"combineName":'',"refundId":"","num":1,"price":5.0,"adjustFee":0.0,"discountFee":1.5,"shareDiscount":0.0,"sharePostFee":0.5,"totalFee":3.5,"payment":4.0,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":'',"actualNum":0,"totalGoodsFee":3.5,"shareAfterTotalFee":3.5,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_011","skuName":"普通件sku_有库存011","brandName":'',"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存011","barCode":"autoops_barcode_011","availableStock":''},{"sourceOrderId":"autojly20210044","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_012","combineCode":"autoops_zhz_goodscode_010","combineNum":1,"combineName":"普通件sku_有库存012","refundId":"","num":1,"price":3.0,"adjustFee":0.0,"discountFee":0.9,"shareDiscount":0.0,"sharePostFee":0.3,"totalFee":2.1,"payment":2.4,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":'',"actualNum":0,"totalGoodsFee":2.1,"shareAfterTotalFee":2.1,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_012","skuName":"普通件sku_有库存012","brandName":'',"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存012","barCode":"autoops_barcode_012","availableStock":''}]}
    resp2 = '{"record":null,"status":200,"message":"success","data":[{"sourceOrderId":"autojly20210044","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_012","combineCode":"autoops_zhz_goodscode_010","combineNum":1,"combineName":"普通件sku_有库存012","refundId":"","num":1,"price":3.0,"adjustFee":0.0,"discountFee":0.9,"shareDiscount":0.0,"sharePostFee":0.3,"totalFee":2.1,"payment":2.4,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":2.1,"shareAfterTotalFee":2.1,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_012","skuName":"普通件sku_有库存012","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存012","barCode":"autoops_barcode_012","availableStock":null},{"sourceOrderId":"autojly20210044","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_011","combineCode":"autoops_zhz_goodscode_010","combineNum":1,"combineName":"普通件sku_有库存011","refundId":"","num":1,"price":2.0,"adjustFee":0.0,"discountFee":0.6,"shareDiscount":0.0,"sharePostFee":0.2,"totalFee":1.4,"payment":1.6,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":1.4,"shareAfterTotalFee":1.4,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_011","skuName":"普通件sku_有库存011","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存011","barCode":"autoops_barcode_011","availableStock":null},{"sourceOrderId":"autojly20210044","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_011","combineCode":"","combineNum":0,"combineName":null,"refundId":"","num":1,"price":5.0,"adjustFee":0.0,"discountFee":1.5,"shareDiscount":0.0,"sharePostFee":0.5,"totalFee":3.5,"payment":4.0,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":3.5,"shareAfterTotalFee":3.5,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_011","skuName":"普通件sku_有库存011","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存011","barCode":"autoops_barcode_011","availableStock":null}]}'
    # resp1 = demjson.decode(resp1)
    resp2 = demjson.decode(resp2)
    # result = a.assert_json_list(resp1, resp2)
    result = jsonpath.jsonpath(resp1, '$..data[(@.length-2)]')
    print(result)
