# -*- coding: utf-8 -*-

'''
@Time    : 2020/7/28 19:22
@Author  : Jia Lu Yun
'''
import json
import re
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.base.get_url_params import GeturlParams
from common.base.get_mysql import GetMySql
from jsonpath import jsonpath

logger = Log().run()


class InterfaceDepend(object):
    def __init__(self):
        self.base_url = GeturlParams()
        self.req = RunMain()
        self.db = GetMySql()
        self.read_excel = ReadExcel()

    # 根据caseid获取excel依赖行数据
    def get_data_value(self, caseid, sheet):
        for case in sheet:
            if caseid in case:
                return case

    # 执行接口请求，拿到返回值
    def get_response(self, case):
        # 取excel一行用例，excel需严格按照模板填写，否则对应错误
        case_name = str(case[1])
        path = str(case[3])
        url = self.base_url.get_url() + path
        query = str(case[4]).encode("utf-8")
        method = str(case[5])
        status_code = str(case[6])
        response = str(case[7])
        sql = str(case[8])
        depend = str(case[9])
        # 执行接口请求
        resp = self.req.run_main(method, url, query)
        # sql不为空，需执行
        if sql != '':
            self.db.connect()
            self.db.update(sql)
            self.db.close()
        if resp.status_code == status_code and response in resp.text:
            logger.info(case_name + '依赖执行完毕')
        return resp.text

    # 传query/path信息和依赖信息，更新query/path（query传string类型，需要decode）
    def update_query_or_path(self, query_or_path, depend, sheet):
        depend = json.loads(depend)
        for caseid in depend:
            case = self.get_data_value(caseid, sheet)
            response = self.get_response(case)
            for params in depend[caseid]:
                key = depend[caseid][params]
                regular = r'"' + key + '":(.*?),'
                value = re.findall(regular, response)
                # 上面的正则匹配不到，可能是位于末位，把逗号换成花括号再次匹配
                if value is None or value == []:
                    regular = r'"' + key + '":(.*?)}'
                    value = re.findall(regular, response)
                    # 逗号 花括号都匹配不到，说明正则匹配不到
                    if value is None or value == []:
                        print(params + "没有对应的value" + str(value))
                        logger.info(params + "没有对应的value")
                    else:
                        value[0] = value[0].replace('"', '')
                        query_or_path = query_or_path.replace(params, value[0])
                else:
                    value[0] = value[0].replace('"', '')
                    query_or_path = query_or_path.replace(params, value[0])
        return query_or_path

    # 替换请求参数中的变量：#(.*?)#
    @classmethod
    def data_replace(cls, string):
        pattren = '#(.*?)#'
        values = re.finditer(pattren, string)
        for value in values:
            replace_value = value.group()
            key = value.group(1)
            new_value = getattr(cls, key)
            string = string.replace(replace_value, new_value)
        return string

    # 响应结果指定json key的值 保存成 变量
    @classmethod
    def data_extractor(cls, response, extractor_string):
        extractors = json.loads(extractor_string)
        response = json.loads(response)
        for hand_attr, jsonpath_exp in extractors.items():
            try:
                value = jsonpath(response, jsonpath_exp)
                setattr(cls, hand_attr, value[0])
                logger.debug('%s的值为: %s', hand_attr, value)
            except Exception as e:
                logger.debug('response值为：%s', response)
                logger.debug('jsonpath_exp值为：%s', jsonpath_exp)
                logger.debug('value值为：%s', jsonpath(response, jsonpath_exp))
                logger.error(e)


if __name__ == '__main__':
    interface_depend = InterfaceDepend()
    response = '{"record":null,"status":200,"message":"success","data":{"total":1,"datas":[{"shopId":"111","shopCode":"SH0125","name":"auto店铺","enabled":true,"platShopName":"","authorised":true,"alipayAuthorised":false,"push":false,"platCode":"TB","authorisedTime":1623317236000,"authorisedExpireTime":1623317236000,"createTime":1623317233000,"updateTime":1623317236000,"mobile":"17829021715","contact":"贾璐芸","address":"西安佳帮手信息中心","remark":"贾璐芸接口测试使用店铺","province":"陕西省","city":"西安市","area":"雁塔区","subPlat":"","appKey":"","appSecret":"","platMcId":"","createBy":"自动化测试用户2","ownerCode":"OW0196","ownerName":"auto货主","bindTime":1623317233000,"omsShopLogisticsRequests":null,"omsShopWarehouseRequests":null}]}}'
    extrator = '{"jlyshopCode":"$..shopCode","jlyshopName":"$..name"}'
    param = '{"shopCode":"#jlyshopCode#","deliveryCondition":"PAY_ON_DELIVERY","orderCategory":"ONLINE_SALES","sourceOrderId":"autojly20210031","payTime":1596769834720,"buyerName":"哄哄","receiverName":"贾姐姐","receiverMobile":"17829021715","buyerRemark":"备注一下，明天再发货","receiverProvince":"陕西省","receiverAddress":"西安理工大学科技园","sellerRemark":"客服：用户要求明天发货","totalFee":"8.00","postFee":1,"payType":"ONLINE_PAY","payId":"autojlypayid000001","discountFee":3,"receiverCity":"西安市","receiverDistrict":"雁塔区","shopName":"#jlyshopName#","subTradeOrders":[{"goodsCode":"autoops_goodscode_011","goodsType":"NORMAL","price":10,"num":1,"discountFee":3,"bigOrderType":"COMMON_PIECE","totalFee":"7.00","judgeCombine":"NO"}]}'
    interface_depend.data_extractor(response, extrator)
    param = interface_depend.data_replace(param)
    print(param)
