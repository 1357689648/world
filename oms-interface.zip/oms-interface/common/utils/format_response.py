# -*- coding: utf-8 -*-

'''
@Time    : 2020/9/1 11:19
@Author  : Jia Lu Yun
'''
import re
from common.base.config_log import Log
import demjson


# 格式化response信息
class FormatResponse(object):
    def __init__(self):
        self.logger = Log().run()

    # 自定义移除，移除 key 对应的键值对
    # key之间用逗号分开
    def remove_element(self, response, keys):
        keys = keys.split(',')
        for key in keys:
            if key == '':
                break
            else:
                reg = r'"' + key + '":(.*?),'
                value = re.findall(reg, response)
                if value is None or value == []:
                    reg = r'"' + key + '":(.*?)}'
                    value = re.findall(reg, response)
                    if value is None or value == []:
                        print(key + "没有对应的value" + str(value))
                        self.logger.info(key + "没有对应的value")
                    else:
                        response = re.sub(reg, '}', response)
                else:
                    response = re.sub(reg, '', response)
        return response

    # 对demjson.encode后的json自定义移除，移除 key 对应的键值对，key之间用逗号分开
    def remove_element_new(self, response, keys):
        keys = keys.split(',')
        for key in keys:
            if key == '':
                break
            else:
                flag = 0
                reg = r'\["' + key + '",(.*?)],'
                print(reg)
                value = re.findall(reg, response)
                print(value)
                if value is not None or value != []:
                    response = re.sub(reg, '', response)
                    flag = 1
                reg = r',\["' + key + '",(.*?)]'
                value = re.findall(reg, response)
                if value is not None or value != []:
                    response = re.sub(reg, '', response)
                    flag = 1
                reg = r'\["' + key + '",(.*?)]'
                value = re.findall(reg, response)
                if value is not None or value != []:
                    response = re.sub(reg, '', response)
                    flag = 1
                if flag == 0:
                    print(key + "没有对应的value" + str(value))
                    self.logger.info(key + "没有对应的value")
        return response

    # 对包含list的json进行排序，便于比较
    def ordered(self, obj):
        if isinstance(obj, dict):
            return sorted((k, self.ordered(v)) for k, v in obj.items())
        if isinstance(obj, list):
            return sorted(self.ordered(x) for x in obj)
        else:
            return obj


if __name__ == '__main__':
    # response = '{"record":null,"status":200,"message":"success","data":{"orderId":"JY2009011300637303527927808","sourceOrderId":"autojly2020001","platCode":"OFFLINE","shopId":"111","shopCode":"SH0010","auditRemark":"","printRemark":"","shopName":"autojly未授权淘宝店铺1","innerStatus":"EDITING","isMultiMerge":false,"stepTradeStatus":null,"stepPaidFee":0.0,"codAmount":8.0,"dapAmount":0.0,"orderCategory":"ONLINE_SALES","markId":"","tradeStatus":"WAIT_DELIVERY","deliveryCondition":"PAY_ON_DELIVERY","payType":"ONLINE_PAY","tradeTime":1596769834000,"payTime":1596769834000,"completeTime":null,"buyerRemark":"备注一下，明天再发货","sellerRemark":"客服：用户要求明天发货","remarkFlag":null,"buyerName":"哄哄","payId":"autojlypayid000001","payAccount":"","receiverName":"贾姐姐","receiverCountry":"","receiverProvince":"陕西省","receiverCity":"西安市","receiverDistrict":"雁塔区","receiverAddress":"西安理工大学科技园","receiverMobile":"17829021715","receiverTelno":"","receiverZip":"","receiverArea":null,"currency":null,"totalFee":10.0,"postFee":1.0,"discountFee":3.0,"payment":8.0,"receivable":null,"tradePrepay":null,"refundAmount":null,"logisticsType":null,"logisticsNo":null,"invoiceType":"NOT_NEED","invoiceTitle":"","invoiceContent":"","tradeFrom":"HAND_CREATE","orderType":"NORMAL","interceptReason":"","goodsSpecies":1,"goodsNum":1,"refundStatus":"NO_REFUND","splitStatus":false,"createTime":1598931072000,"updateTime":1598931073000,"subTradeOrders":[{"subOrderId":"1300637303976718336","orderId":"JY2009011300637303527927808","sourceOrderId":"autojly2020001","sourceSubOrderId":"AD2009011300637303972524032","auditRemark":null,"printRemark":null,"platCode":"OFFLINE","orderStatus":null,"refundStatus":"NO_REFUND","goodsCode":"autojly_goodscode_011","spuName":"autojly货品01","skuName":"普通件sku_有库存011","spuCode":"autojly001","skuCode":"autojly_skucode_011","combineCode":"","combineNum":0,"refundId":"","num":1,"price":10.0,"adjustFee":0.0,"discountFee":3.0,"shareDiscount":0.0,"sharePostFee":1.0,"totalFee":7.0,"payment":8.0,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"createTime":1598931072000,"updateTime":1598931072000,"actualNum":0,"totalGoodsFee":7.0,"shareAfterTotalFee":7.0,"platSpuName":"autojly货品01","platSkuName":"普通件sku_有库存011"}],"splitTime":null,"sellerNos":null,"auditTime":null,"innerMark":"","warehouseCode":"","warehouseOutCode":"","warehouseName":null,"warehouseType":null,"logisticsName":null,"logisticsCode":"","ownerCode":"OW0038","ownerName":null,"expressCode":"","containGift":false,"checkOutStatus":false,"checkBy":"","frozenStatus":false,"frozenReason":null,"failReason":"","delayTime":null,"cartonCode":""}}'
    response1 = '{"record":null,"status":200,"message":"success","data":[{"sourceOrderId":"autogyk20210002","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_012","combineCode":"autoops_zhz_goodscode_003","combineNum":1,"combineName":"普通件sku_有库存012","refundId":"","num":1,"price":6.0,"adjustFee":0.0,"discountFee":1.8,"shareDiscount":0.0,"sharePostFee":0.6,"totalFee":4.2,"payment":4.8,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":4.2,"shareAfterTotalFee":4.2,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_012","skuName":"普通件sku_有库存012","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存012","barCode":"autoops_barcode_012","availableStock":null,"goodsAttr":"AUTO_MANAGE"},{"sourceOrderId":"autogyk20210002","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_011","combineCode":"autoops_zhz_goodscode_003","combineNum":1,"combineName":"普通件sku_有库存011","refundId":"","num":1,"price":4.0,"adjustFee":0.0,"discountFee":1.2,"shareDiscount":0.0,"sharePostFee":0.4,"totalFee":2.8,"payment":3.2,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":2.8,"shareAfterTotalFee":2.8,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_011","skuName":"普通件sku_有库存011","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存011","barCode":"autoops_barcode_011","availableStock":null,"goodsAttr":"AUTO_MANAGE"}]}'
    response2 = '{"status":200,"record":null,"message":"success","data":[{"sourceOrderId":"autogyk20210002","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_012","combineCode":"autoops_zhz_goodscode_003","combineNum":1,"combineName":"普通件sku_有库存012","refundId":"","num":1,"price":6.0,"adjustFee":0.0,"discountFee":1.8,"shareDiscount":0.0,"sharePostFee":0.6,"totalFee":4.2,"payment":4.8,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":4.2,"shareAfterTotalFee":4.2,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_012","skuName":"普通件sku_有库存012","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存012","barCode":"autoops_barcode_012","availableStock":null,"goodsAttr":"AUTO_MANAGE"},{"sourceOrderId":"autogyk20210002","platCode":"OFFLINE","orderStatus":"WAIT_DELIVERY","refundStatus":"NO_REFUND","goodsCode":"autoops_goodscode_011","combineCode":"autoops_zhz_goodscode_003","combineNum":1,"combineName":"普通件sku_有库存011","refundId":"","num":1,"price":4.0,"adjustFee":0.0,"discountFee":1.2,"shareDiscount":0.0,"sharePostFee":0.4,"totalFee":2.8,"payment":3.2,"refundFee":0.0,"goodsType":"NORMAL","bigOrderType":"COMMON_PIECE","remark":null,"actualNum":0,"totalGoodsFee":2.8,"shareAfterTotalFee":2.8,"spuCode":"autoops001","spuName":"autoops货品01","spuNikName":"","imageUrl":"http://jbs-common-files.oss-cn-beijing.aliyuncs.com/dev/oms/1346385879256035328.jpg?Expires=1767604783&OSSAccessKeyId=LTAI4FrxCn9aJJkw36pWkwXb&Signature=037iaXIPjDbayA6j92zzyjb9nC8%3D","skuCode":"autoops_skucode_011","skuName":"普通件sku_有库存011","brandName":null,"platSpuName":"autoops货品01","platSkuName":"普通件sku_有库存011","barCode":"autoops_barcode_011","availableStock":null,"goodsAttr":"AUTO_MANAGE"}]}'
    # excel中忽略key格式如下（对返回结果先排序，再忽略，再比对）：
    keys = "totalGoodsFee"
    reformat = FormatResponse()
    resp_new1 = reformat.ordered(demjson.decode(response1))
    resp_new2 = reformat.ordered(demjson.decode(response2))
    resp_new1 = reformat.remove_element_new(demjson.encode(resp_new1), keys)
    resp_new2 = reformat.remove_element_new(demjson.encode(resp_new2), keys)
    print(resp_new1==resp_new2)
