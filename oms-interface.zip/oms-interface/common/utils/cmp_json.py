# -*- coding: utf-8 -*-
# @Time : 2020/7/16 16:54
# @Author : BruceGao
# @FileName: cmp_json.py
# @Software: PyCharm

import json


class CmpJson(object):
    """
    去除无用的json数据
    """
    def cmp_json_single(self, jsondata, keys):
        del jsondata['data'][keys]
        result = json.dumps(jsondata, ensure_ascii=False, indent=1)
        return result

    def cmp_json_middle(self, jsondata, keys):
        for i in range(len(jsondata['data'])):
            del jsondata['data'][i][keys]
        result = json.dumps(jsondata, ensure_ascii=False, indent=1)
        return result

    def cmp_json_multiple(self, jsondata, key, keys):
        for i in range(len(jsondata['data'][key])):
            del jsondata['data'][key][i][keys]
        result = json.dumps(jsondata, ensure_ascii=False, indent=1)
        return result


if __name__ == '__main__': #测试一下是否将json中实时变量去除
    data = {'record': None, 'status': 200, 'message': '成功', 'data': {'token': 'bdf3a37792989bc3f65d1b0fc2448751', 'updateTime': None, 'gender': 0, 'lastLoginTime': None}}
    print(CmpJson().cmp_json_single(data,'token'))
    data1 = {'record': None, 'status': 200, 'message': '成功', 'data': {'total': 43, 'datas': [
        {'roleId': '387238859796856832', 'roleName': '组合装管理（附加）', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-07-17T05:56:25.000+0000', 'description': 'AssemblyManager ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '1273572794791694336', 'note': ''},
        {'roleId': '387238859796856833', 'roleName': '仓库盘点权限（附加）', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-06T08:11:45.000+0000', 'description': 'WarehouseChecker ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856834', 'roleName': '稽查组', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-06T08:11:46.000+0000', 'description': 'InspectionGroup ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856835', 'roleName': '售后维修', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-06T08:11:47.000+0000', 'description': 'AfterRepair ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856836', 'roleName': 'HRBP', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-06T08:11:52.000+0000', 'description': 'HRBP ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856837', 'roleName': '业务公共（客服）', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-06T08:11:54.000+0000', 'description': 'BusinessCommonCusSer ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856838', 'roleName': '仓储调拨', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-06T08:11:56.000+0000', 'description': 'WarehouseAlloction ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856839', 'roleName': '开发组', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-21T02:20:51.000+0000', 'description': 'Developer ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '388739129497452544', 'note': ''},
        {'roleId': '387238859796856840', 'roleName': '委外操作', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2019-10-31T03:11:23.000+0000', 'description': 'OuterOpt ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387238859796856841', 'roleName': '独立仓', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-04-18T08:37:53.000+0000', 'description': 'StandWh ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856842', 'roleName': '订单审核查看', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-03-14T01:50:29.000+0000', 'description': 'OrderCheckerSelect ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387238859796856843', 'roleName': 'PMC', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2020-05-20T11:30:48.000+0000', 'description': 'PMC ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '416589841853468672', 'note': ''},
        {'roleId': '387238859796856844', 'roleName': '客户分析（附加）', 'createTime': '2019-10-31T03:11:23.000+0000',
         'updateTime': '2019-10-31T03:11:23.000+0000', 'description': 'CusteSerAnaly ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707971', 'roleName': '运营基础权限', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-05-06T08:11:39.000+0000', 'description': 'OperateBasic', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387237507066707972', 'roleName': '商品资料管理', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'GoodsDataManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707973', 'roleName': '物流部客服', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-04-18T09:04:46.000+0000', 'description': 'LogisticsCustomerSer', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707974', 'roleName': '财务', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-05-11T13:26:36.000+0000', 'description': 'Finance', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '416589841853468672', 'note': ''},
        {'roleId': '387237507066707975', 'roleName': '系统管理员', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'SysManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707976', 'roleName': '仓储货管员', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'WarehouseManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707977', 'roleName': '退货仓权限', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ReturnWhManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707978', 'roleName': '打单室管理组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'BookingRoomManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707979', 'roleName': '货品调拨', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'GoodsAlloction', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707980', 'roleName': '仓储财务', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'WarehouseFinance', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707981', 'roleName': '客服管理组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-05-07T11:32:51.000+0000', 'description': 'CustomerSerManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '382159522753548288', 'note': ''},
        {'roleId': '387237507066707982', 'roleName': '赠品策略（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'GiftStrategy', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707983', 'roleName': '运营管理组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'OperateManage', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707984', 'roleName': '无效货品处理（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'InvalidGoods', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707985', 'roleName': '项目二组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ProjectTwoGroup', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707986', 'roleName': '项目三组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-05-13T10:18:57.000+0000', 'description': 'ProjectThreeGroup', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '387608278734831616', 'note': ''},
        {'roleId': '387237507066707987', 'roleName': '项目四组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ProjectFourGroup', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707988', 'roleName': '项目六组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ProjectSixGroup', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707989', 'roleName': '项目七组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ProjectSevenGroup ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707990', 'roleName': '项目八组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ProjectEightGroup ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707991', 'roleName': '项目九组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'ProjectNineGroup ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707992', 'roleName': '微营销（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'MicroMarketing', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707993', 'roleName': '业务公共（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2019-10-31T03:07:42.000+0000', 'description': 'BusinessCommon ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707994', 'roleName': '孵化器组（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-02-17T01:00:27.000+0000', 'description': 'IncubatorGroup ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387237507066707995', 'roleName': '手工订单权限（附加）', 'createTime': '2019-10-31T03:07:42.000+0000',
         'updateTime': '2020-05-06T08:11:41.000+0000', 'description': 'ManualOrder ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '386665878234284033', 'note': ''},
        {'roleId': '387237507066707968', 'roleName': '售前客服', 'createTime': '2019-10-31T03:07:41.000+0000',
         'updateTime': '2019-10-31T03:07:41.000+0000', 'description': 'BeforeCustomerSer', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707969', 'roleName': '售后客服', 'createTime': '2019-10-31T03:07:41.000+0000',
         'updateTime': '2020-05-06T08:11:37.000+0000', 'description': 'AfterCustomerSer', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '387237507066707970', 'roleName': '跟单员', 'createTime': '2019-10-31T03:07:41.000+0000',
         'updateTime': '2019-10-31T03:07:41.000+0000', 'description': 'FollowOrder', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '963903739941949541', 'note': ''},
        {'roleId': '381813619354112001', 'roleName': '审单员', 'createTime': '2019-10-30T03:06:24.000+0000',
         'updateTime': '2020-02-14T09:20:43.000+0000', 'description': 'Checker ', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '424632977905307648', 'note': ''},
        {'roleId': '381813619354112000', 'roleName': '管理员', 'createTime': '2019-10-16T03:53:35.000+0000',
         'updateTime': '2020-07-17T05:59:08.000+0000', 'description': 'Manager', 'isDel': False,
         'createEmployeeId': '963903739941949541', 'updateEmployeeId': '1273572794791694336', 'note': ''}]}}

    CmpJson().cmp_json_multiple(data1,'datas','createTime')
    CmpJson().cmp_json_multiple(data1,'datas', 'updateTime')
    CmpJson().cmp_json_multiple(data1,'datas', 'createEmployeeId')
    CmpJson().cmp_json_multiple(data1,'datas', 'updateEmployeeId')
    print(json.dumps(data1,ensure_ascii = False,indent = 1))
