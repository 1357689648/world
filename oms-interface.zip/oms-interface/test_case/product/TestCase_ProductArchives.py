# -*- coding: utf-8 -*-
# @Time : 2020/12/31 15:28
# @Author : Bruce.Gao
# @FileName: TestCase_ProductArchives.py
# @Software: PyCharm

import unittest
import os
import json
import demjson
import paramunittest
from common.base.get_url_params import GeturlParams
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.utils.interface_depend import InterfaceDepend
from common.utils.format_response import FormatResponse
from common.base import get_mysql, get_path_info
import configparser

logger = Log().run()
url = GeturlParams().get_url()
ProductArchives_xls = ReadExcel().get_xls('product/ProductArchives.xlsx', 'ProductArchives')
RedayData_xls = ReadExcel().get_xls('product/ProductArchives.xlsx', 'RedayData')
DelData_xls = ReadExcel().get_xls('product/ProductArchives.xlsx', 'DelData')
path = get_path_info.get_path()
config_path = os.path.join(path, 'base/base.ini')
config = configparser.ConfigParser()
config.read(config_path, encoding="utf-8")
global null, false, true
null = None
false = False
true = True

@paramunittest.parametrized(*RedayData_xls)
class TestARedayData(unittest.TestCase):
    """
    货品档案测试数据准备
    """
    def setParameters(self, case_id,case_name, sql):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.sql = str(sql)

    def test_redayData(self):
        db = get_mysql.GetMySql()
        db.connect()
        db.insert(self.sql)

@paramunittest.parametrized(*ProductArchives_xls)
class TestBProductArchives(unittest.TestCase):
    """
    货品档案
    """
    maxDiff = None
    def setParameters(self, case_id,case_name, execute, path, query, method, status_code, response, sql, depend, ignore):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query)
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)
        self.ignore = str(ignore)

    def setUp(self):
        print("\n" + self.case_name + ":\n\n测试开始前准备\n\n" + "接口请求数据：\n")

    def tearDown(self):
        print("测试结束\n输出log\n完结!\n\n")

    def test_checkResult(self):

        if self.depend != '':
            self.query = InterfaceDepend().update_query_or_path(self.query, self.depend, ProductArchives_xls)
            self.path = InterfaceDepend().update_query_or_path(self.path, self.depend, ProductArchives_xls)
        get_url = url + self.path
        req = RunMain().run_main(self.method, get_url, self.query.encode('utf-8'))
        data = json.loads(req.text)
        res = json.dumps(data, ensure_ascii=False, indent=1)
        print("url:" + get_url + "\n" + "query:\n" + self.query)
        print("\n接口返回数据:\n\n" + res + "\n")

        if self.ignore != '':
            res = FormatResponse().remove_element(req.text, self.ignore)
        self.assertEqual(req.status_code,self.status_code)
        self.assertEqual(demjson.decode(res),demjson.decode(self.response))
        print("结果数据为：\n" + res)
        print("基线数据为：\n" + self.response)

@paramunittest.parametrized(*DelData_xls)
class TestCDelData(unittest.TestCase):
    """
    货品档案测试数据删除
    """
    def setParameters(self, case_id,case_name, sql):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.sql = str(sql)

    def test_delData(self):
        db = get_mysql.GetMySql()
        db.connect()
        db.delete(self.sql)

if __name__ == '__main__':
    unittest.main()