# -*- coding: utf-8 -*-
# @Time : 2020/7/20 19:25
# @Author : Bruce.Gao
# @FileName: TestCase_OwnerManager.py
# @Software: PyCharm

import unittest
import os
import json
import demjson
import paramunittest
from common.base.get_url_params import GeturlParams
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.utils.cmp_json import CmpJson
from common.base import get_mysql, get_path_info
import configparser

logger = Log()
url = GeturlParams().get_url()
PlatManager_xls = ReadExcel().get_xls('case.xlsx', 'OwnerManager')
path = get_path_info.get_path()
config_path = os.path.join(path, 'base/base.ini')
config = configparser.ConfigParser()
config.read(config_path,encoding="utf-8")
global null,false,true
null = None
false = False
true = True

@paramunittest.parametrized(*PlatManager_xls)
class TestPlatManager(unittest.TestCase):
    """
    货主管理
    """
    def setParameters(self,case_name,path,query,method,status_code,response,sql):
        """
        set params
        :param case_name:
        :param path
        :param query
        :param method
        :return:
        """
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query)
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)
        self.sql = str(sql)

    def setUp(self):
        """

        :return:
        """
        print("\n" + self.case_name + ":\n\n测试开始前准备\n\n" + "接口请求数据：\n")

    def tearDown(self):
        print("测试结束\n输出log\n完结!\n\n")

    def test_checkResult(self):

        if self.case_name.endswith("_货主"):
            db = get_mysql.GetMySql()
            db.connect()
            ownercode = db.select(self.sql)[0][0]
            get_url = url + self.path
            get_query = json.dumps(dict(eval(self.query)))
            req = RunMain().run_main(self.method, get_url, get_query.encode('utf-8'))
            data = json.loads(req.text)
            res = json.dumps(data, ensure_ascii = False, indent = 1)
            print("url:" + get_url + "\n" + "query:\n" + get_query)
            print("\n接口返回数据:\n\n" + res + "\n")

            self.assertEqual(req.status_code, self.status_code)

        elif self.case_name.startswith("查询"):
            get_url = url + self.path
            req = RunMain().run_main(self.method, get_url, self.query.encode('utf-8'))
            data = json.loads(req.text)
            res = json.dumps(data, ensure_ascii=False, indent=1)
            print("url:" + get_url + "\n" + "query:\n" + self.query)
            print("\n接口返回数据:\n\n" + res + "\n")

            CmpJson().cmp_json_multiple(data,'datas','createTime')
            result = CmpJson().cmp_json_multiple(data,'datas', 'updateTime')
            self.assertEqual(req.status_code, self.status_code)
            db = get_mysql.GetMySql()
            db.connect()
            ownercode = db.select(self.sql)[0][0]
            response = json.dumps(dict(eval(self.response)),ensure_ascii = False,indent = 1)
            self.assertEqual(json.loads(result), demjson.decode(response))
            print("结果数据为：\n" + result)
            print("基线数据为：\n" + response)

        elif self.case_name == "新建店铺":
            get_url = url + self.path
            req = RunMain().run_main(self.method, get_url, self.query.encode('utf-8'))
            data = json.loads(req.text)
            res = json.dumps(data, ensure_ascii=False, indent=1)
            print("url:" + get_url + "\n" + "query:\n" + self.query)
            print("\n接口返回数据:\n\n" + res + "\n")

            CmpJson().cmp_json_single(data, 'createTime')
            result = CmpJson().cmp_json_single(data, 'updateTime')
            self.assertEqual(req.status_code, self.status_code)
            db = get_mysql.GetMySql()
            db.connect()
            shopcode = db.select(self.sql)[0][0]
            response = json.dumps(dict(eval(self.response)), ensure_ascii=False, indent=1)
            self.assertEqual(json.loads(result), demjson.decode(response))
            print("结果数据为：\n" + result)
            print("基线数据为：\n" + response)

        elif self.case_name == "店铺绑定":
            db = get_mysql.GetMySql()
            db.connect()
            ownercode = db.select(self.sql)[0][0]
            shopcode = db.select(self.sql)[1][0]
            get_url = url + self.path
            get_query = json.dumps(dict(eval(self.query)))
            req = RunMain().run_main(self.method, get_url, get_query.encode('utf-8'))
            data = json.loads(req.text)
            res = json.dumps(data, ensure_ascii=False, indent=1)
            print("url:" + get_url + "\n" + "query:\n" + get_query)
            print("\n接口返回数据:\n\n" + res + "\n")

            self.assertEqual(req.status_code, self.status_code)
            response = json.dumps(dict(eval(self.response)), ensure_ascii=False, indent=1)
            self.assertEqual(data, demjson.decode(response))
            print("结果数据为：\n" + res)
            print("基线数据为：\n" + response)

        elif self.case_name == "仓库绑定":
            db = get_mysql.GetMySql()
            db.connect()
            ownercode = db.select(self.sql)[0][0]
            warehousecode = db.select(self.sql)[1][0]
            get_query = json.dumps(dict(eval(self.query)))
            get_url = url + self.path
            req = RunMain().run_main(self.method, get_url, get_query.encode('utf-8'))
            data = json.loads(req.text)
            res = json.dumps(data, ensure_ascii=False, indent=1)
            print("url:" + get_url + "\n" + "query:\n" + get_query)
            print("\n接口返回数据:\n\n" + res + "\n")

            result = CmpJson().cmp_json_middle(data, 'createTime')
            self.assertEqual(req.status_code, self.status_code)
            response = json.dumps(dict(eval(self.response)), ensure_ascii=False, indent=1)
            self.assertEqual(json.loads(result), demjson.decode(response))
            print("结果数据为：\n" + result)
            print("基线数据为：\n" + response)

        else:
            get_url = url + self.path
            req = RunMain().run_main(self.method, get_url, self.query.encode('utf-8'))
            data = json.loads(req.text)
            res = json.dumps(data, ensure_ascii=False, indent=1)
            print("url:" + get_url + "\n" + "query:\n" + self.query)
            print("\n接口返回数据:\n\n" + res + "\n")

            CmpJson().cmp_json_single(data, 'createTime')
            result = CmpJson().cmp_json_single(data, 'updateTime')
            self.assertEqual(req.status_code, self.status_code)
            db = get_mysql.GetMySql()
            db.connect()
            ownercode = db.select(self.sql)[0][0]
            response = json.dumps(dict(eval(self.response)),ensure_ascii = False,indent = 1)
            self.assertEqual(json.loads(result), demjson.decode(response))
            print("结果数据为：\n" + result)
            print("基线数据为：\n" + response)


if __name__ == '__main__':
    unittest.main()
