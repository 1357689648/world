# -*- coding: utf-8 -*-
# @Time : 2020/7/24 13:56
# @Author : Bruce.Gao
# @FileName: TestCase_DelData.py
# @Software: PyCharm

import unittest
import paramunittest
from common.base.read_excel import ReadExcel
from common.base.config_log import Log
from common.base import get_mysql


DelData_xls = ReadExcel().get_xls('DelData.xlsx', 'DelData')
logger = Log().run()


@paramunittest.parametrized(*DelData_xls)
class TestDelData_xls(unittest.TestCase):
    """
    删除数据
    """
    def setParameters(self, case_id, case_name, sql):
        """
        set params
        :param case_name:
        :param path
        :param query
        :param method
        :return:
        """
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.sql = str(sql)

    def setUp(self):
        """
        :return:
        """
        print("\n" + self.case_name + ":\n\n测试开始前准备\n")

    def tearDown(self):
        print("测试结束\n输出log\n完结!\n\n")

    def test_checkResult(self):
        db = get_mysql.GetMySql()
        db.connect()
        db.delete(self.sql)
        logger.info(str(self.case_name))


if __name__ == '__main__':
    unittest.main()
