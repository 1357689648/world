#coding = utf-8
#author_="bruce.gao"
#date:2019/07/11 19:13

import unittest
import os
import json
import demjson
import paramunittest
from common.base.get_url_params import GeturlParams
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.base import get_path_info
from common.utils.cmp_json import CmpJson
import configparser
import hashlib

logger = Log().run()
url = GeturlParams().get_url()
login_xls = ReadExcel().get_xls('case.xlsx', 'login')
path = get_path_info.get_path()
config_path = os.path.join(path, 'base/base.ini')
config = configparser.ConfigParser()
config.read(config_path, encoding="utf-8")

@paramunittest.parametrized(*login_xls)
class TestLogin(unittest.TestCase):
    """
    登录
    """
    def setParameters(self,case_name,path,query,method,status_code,response):
        """
        set params
        :param case_name:
        :param path
        :param query
        :param method
        :return:
        """
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query)
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)

    def setUp(self):
        """
        :return:
        """
        print("\n" + self.case_name + ":\n\n测试开始前准备\n\n" + "接口请求数据：\n")

    def tearDown(self):
        print("测试结束\n输出log\n完结!\n\n")

    def test_checkResult(self):
        get_url = url + self.path
        req = RunMain().run_main(self.method, get_url, self.query.encode('utf-8'))
        data = json.loads(req.text)
        res = json.dumps(data, ensure_ascii=False, indent=1)
        print("url:" + get_url + "\n" + "query:\n" + self.query)
        print("\n接口返回数据:\n\n" + res + "\n")

        s = data['data']['employeeId'] + data['data']['token']    #employeeId和token拼接在一起
        config.set("HEADER","token",str(hashlib.md5(s.encode()).hexdigest()))  #写入token到配置文件
        config.set("HEADER","employeeid",str(data['data']['employeeId']))  #写入employeeId到配置文件
        config.write(open(config_path,'w',encoding='utf-8'))

        result = CmpJson().cmp_json_single(data,'token')
        self.assertEqual(req.status_code, self.status_code)
        self.assertEqual(json.loads(result),demjson.decode(self.response))
        print("结果数据为：\n" + result)
        print("基线数据为：\n" + self.response)

        logger.info(req)
        logger.info(str(self.case_name))
        logger.info(data)
        return res


if __name__ == '__main__':
    unittest.main()