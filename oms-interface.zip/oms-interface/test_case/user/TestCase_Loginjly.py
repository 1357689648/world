# coding = utf-8

import unittest
import os
import json
import paramunittest
from common.base.get_url_params import GeturlParams
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.base import get_path_info
from common.utils.cmp_json import CmpJson
import configparser
import hashlib

logger = Log().run()
url = GeturlParams().get_url()
login_xls = ReadExcel().get_xls('login.xlsx', 'login')
path = get_path_info.get_path()
config_path = os.path.join(path, 'base/base.ini')
config = configparser.ConfigParser()
config.read(config_path, encoding="utf-8")


@paramunittest.parametrized(*login_xls)
class TestLogin(unittest.TestCase):
    """
    登录
    """

    def setParameters(self, case_name, path, query, method, status_code, response):
        """
        set params
        :param case_name:
        :param path
        :param query
        :param method
        :return:
        """
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query)
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)

    def setUp(self):
        logger.info('\n%s:jly账号登录 \n' % self.case_name)
        print('%s:jly账号登录 \n' % self.case_name)

    def tearDown(self):
        pass

    def test_checkResult(self):

        get_url = url + self.path
        req = RunMain().run_main(self.method, get_url, self.query.encode('utf-8'))
        data = json.loads(req.text)
        res = json.dumps(data, ensure_ascii=False, indent=1)
        print("url:" + get_url + "\n" + "query:\n" + self.query)
        print("\n接口返回数据:\n\n" + res + "\n")

        # employeeId和token拼接在一起
        s = data['data']['employeeId']+data['data']['token']
        # 写入token到配置文件
        config.set("HEADER", "token", str(hashlib.md5(s.encode()).hexdigest()))
        # 写入employeeId到配置文件
        config.set("HEADER", "employeeId", str(data['data']['employeeId']))
        config.write(open(config_path, 'w', encoding='utf-8'))

        result = CmpJson().cmp_json_single(data, 'token')
        result = CmpJson().cmp_json_single(json.loads(result), 'dataToken')
        print("结果数据为：\n" + result)
        print("基线数据为：\n" + self.response)
        self.assertEqual(req.status_code, self.status_code)
        self.assertEqual(json.loads(result), json.loads(self.response))

        logger.info(req)
        logger.info(str(self.case_name))
        logger.info(data)
        return res


if __name__ == '__main__':
    unittest.main()
