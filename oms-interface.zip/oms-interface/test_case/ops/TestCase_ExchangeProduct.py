# -*- coding: utf-8 -*-

'''
@Time    : 2021/2/22 13:44
@Author  : Jia Lu Yun
'''
import unittest
import paramunittest
import demjson
import time
from test_case.ops.test_depend.base_data import BaseData
from test_case.ops.test_depend.base_product import BaseProduct
from common.base.read_excel import ReadExcel
from common.utils.assert_json import AssertJson
from common.base.config_log import Log
from common.base.get_mysql import GetMySql
from common.base.config_http import RunMain
from common.utils.interface_depend import InterfaceDepend
from common.base.get_url_params import GeturlParams
from common.utils.format_response import FormatResponse

read_excel = ReadExcel()
base_product = BaseProduct()
base_data = BaseData()
logger = Log().run()
interface_depend = InterfaceDepend()
base_url = GeturlParams()
format_response = FormatResponse()
db = GetMySql()
req = RunMain()
assert_json = AssertJson()


# 基础数据准备
# class TestAAAPrepare(unittest.TestCase):
#     def test_prepare(self):
#         base_product.create_base_product()
#         base_data_excel = read_excel.get_xls('ops/exchangeProduct.xlsx', 'base_data')
#         for data in base_data_excel:
#             if data[0] != 'owner_name':
#                 base_data.create_base_data(data[0], data[1], data[2], data[3], data[4], data[5])


# 基础数据清理
# class TestZZZClear(unittest.TestCase):
#     def test_clear(self):
#         base_product.clear_base_product()
#         base_data_excel = read_excel.get_xls('ops/manualTradeOrderCase.xlsx', 'base_data')
#         for data in base_data_excel:
#             if data[0] != 'owner_name':
#                 base_data.clear_base_data(data[0], data[1], data[2], data[3], data[4], data[5])


# 换货用例
exchange_product = read_excel.get_xls('ops/exchangeProduct-gyk.xlsx', 'exchangeProduct')
@paramunittest.parametrized(*exchange_product)
class TestBExchangeProduct(unittest.TestCase):
    maxDiff = None

    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend, ignore):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)
        self.ignore = str(ignore)

    def setUp(self):
        logger.info("↓------test_exchange_product %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        logger.info("↑------test_exchange_product %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_exchange_product")
    def test_exchange_product(self):
        if self.execute == 'no':
            self.assertEqual('依赖接口，非用例', '依赖接口，非用例')
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query、path值
            if self.depend != '':
                self.query = interface_depend.update_query_or_path(self.query.decode(), self.depend, exchange_product)
                self.path = interface_depend.update_query_or_path(self.path, self.depend, exchange_product)
                self.response = interface_depend.update_query_or_path(self.response, self.depend, exchange_product)
                self.query = self.query.encode("utf-8")
            url = base_url.get_url() + self.path
            res = req.run_main(self.method, url, self.query)
            self.assertEqual(res.status_code, self.status_code)
            res = res.text
            res = format_response.ordered(demjson.decode(res))
            self.response = format_response.ordered(demjson.decode(self.response))
            # 若存在无需比较的元素，对response进行清理
            if self.ignore != '':
                res = format_response.remove_element_new(demjson.encode(res), self.ignore)
                self.response = format_response.remove_element_new(demjson.encode(self.response), self.ignore)
            # 增加3s的等待重试，避免订单状态拆单中，影响校验结果
            if self.response != res:
                time.sleep(3)
                res = req.run_main(self.method, url, self.query)
                self.assertEqual(res.status_code, self.status_code)
                res = res.text
                res = format_response.ordered(demjson.decode(res))
                if self.ignore != '':
                    res = format_response.remove_element_new(demjson.encode(res), self.ignore)
            # result = assert_json.assert_json_list(demjson.decode(self.response), demjson.decode(res))
            # if result is False:
            #     print(res + "!=" + self.response)
            print(self.response)
            print(res)
            self.assertEqual(self.response, res)

            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.insert(self.sql)
                db.close()


# 清理换货测试用例的订单数据
clear_exchange_product = read_excel.get_xls('ops/exchangeProduct-gyk.xlsx', 'clearExchangeProduct')
@paramunittest.parametrized(*clear_exchange_product)
class TestYExchangeProductClear(unittest.TestCase):
    def setParameters(self, case_id, case_name, sql, es_execute, es_path, es_query, es_method):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.sql = str(sql)
        self.es_execute = str(es_execute)
        self.es_path = str(es_path)
        self.es_query = str(es_query).encode("utf-8")
        self.es_method = str(es_method)

    def setUp(self):
        logger.info("↓------test_clear_exchange_product %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        logger.info("↑------test_clear_exchange_product %s %s开始------↓" % (self.case_id, self.case_name))

    @unittest.skip("不执行test_clear_exchange_product")
    def test_clear_exchange_product(self):
        # 清理数据库数据
        if self.sql != '':
            db.connect()
            db.insert(self.sql)
            db.close()
        # 清理es数据
        if self.es_execute == 'yes':
            response = req.run_main(self.es_method, self.es_path, self.es_query)
            if '"deleted": 0' in response.text:
                logger.error('%s未成功清理es数据' % self.case_name)
        self.assertEqual('清理无校验', '清理无校验')


if __name__ == '__main__':
    unittest.main()
