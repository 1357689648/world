# -*- coding: utf-8 -*-

'''
@Time    : 2020/7/17 13:50
@Author  : Jia Lu Yun
'''

import unittest
import paramunittest
import demjson
from common.base.read_excel import ReadExcel
from common.base.config_log import Log
from common.utils.interface_depend import InterfaceDepend
from common.base.get_mysql import GetMySql
from common.base.config_http import RunMain
from common.base.get_url_params import GeturlParams
from common.utils.format_response import FormatResponse
from test_case.ops.test_depend.base_data import BaseData
from test_case.ops.test_depend.base_product import BaseProduct

log = Log().run()
read_excel = ReadExcel()
interface_depend = InterfaceDepend()
db = GetMySql()
req = RunMain()
base_url = GeturlParams()
format_response = FormatResponse()
base_data = BaseData()
base_product = BaseProduct()


# 基础数据准备
class TestAAAPrepare(unittest.TestCase):
    def test_prepare(self):
        base_product.create_base_product()
        base_data_excel = read_excel.get_xls('ops/manualTradeOrderCase.xlsx', 'base_data')
        for data in base_data_excel:
            if data[0] != 'owner_name':
                base_data.create_base_data(data[0], data[1], data[2], data[3], data[4], data[5])


# 基础数据清理
class TestZZZClear(unittest.TestCase):
    def test_clear(self):
        base_product.clear_base_product()
        base_data_excel = read_excel.get_xls('ops/manualTradeOrderCase.xlsx', 'base_data')
        for data in base_data_excel:
            if data[0] != 'owner_name':
                base_data.clear_base_data(data[0], data[1], data[2], data[3], data[4], data[5])


# 手工建单新建测试用例
manual_create_order = read_excel.get_xls('ops/manualTradeOrderCase.xlsx', 'manualCreateOrder')
@paramunittest.parametrized(*manual_create_order)
class TestBManualCreateOrder(unittest.TestCase):
    maxDiff = None

    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend, ignore):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)
        self.ignore = str(ignore)

    def setUp(self):
        log.info("↓------test_manual_create_order %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_manual_create_order %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_manual_create_order")
    def test_manual_create_order(self):
        if self.execute == 'no':
            self.assertEqual('依赖接口，非用例', '依赖接口，非用例')
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query、path值
            if self.depend != '':
                self.query = interface_depend.update_query_or_path(self.query.decode(), self.depend, manual_create_order)
                self.path = interface_depend.update_query_or_path(self.path, self.depend, manual_create_order)
                self.query = self.query.encode("utf-8")
            url = base_url.get_url() + self.path
            res = req.run_main(self.method, url, self.query)
            self.assertEqual(res.status_code, self.status_code)
            res = res.text
            # 若存在无需比较的元素，对response进行清理
            if self.ignore != '':
                res = format_response.remove_element(res, self.ignore)
                self.response = format_response.remove_element(self.response, self.ignore)
            self.assertEqual(demjson.decode(self.response), demjson.decode(res))

            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.insert(self.sql)
                db.close()


# 手工建单编辑测试用例
manual_edit_order = read_excel.get_xls('ops/manualTradeOrderCase.xlsx', 'manualEditOrder')
@paramunittest.parametrized(*manual_edit_order)
class TestCManualEditOrder(unittest.TestCase):
    maxDiff = None

    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend, ignore):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)
        self.ignore = str(ignore)

    def setUp(self):
        log.info("↓------test_manual_edit_order %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_manual_edit_order %s %s完成------↑" % (self.case_id, self.case_name))

    @unittest.skip("不执行test_manual_edit_order")
    def test_manual_edit_order(self):
        if self.execute == 'no':
            self.assertEqual('依赖接口，非用例', '依赖接口，非用例')
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query、path值
            if self.depend != '':
                self.query = interface_depend.update_query_or_path(self.query.decode(), self.depend, manual_create_order)
                self.path = interface_depend.update_query_or_path(self.path, self.depend, manual_create_order)
                self.query = self.query.encode("utf-8")
            url = base_url.get_url() + self.path
            res = req.run_main(self.method, url, self.query)
            self.assertEqual(res.status_code, self.status_code)
            res = res.text
            # 若存在无需比较的元素，对response进行清理
            if self.ignore != '':
                res = format_response.remove_element(res, self.ignore)
                self.response = format_response.remove_element(self.response, self.ignore)
            self.assertEqual(demjson.decode(self.response), demjson.decode(res))

            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.insert(self.sql)
                db.close()


# 清理手工建单测试用例的订单数据
clear_manual_order = read_excel.get_xls('ops/manualTradeOrderCase.xlsx', 'clearManualOrder')
@paramunittest.parametrized(*clear_manual_order)
class TestYManualClearOrder(unittest.TestCase):
    def setParameters(self, case_id, case_name, sql, es_execute, es_path, es_query, es_method):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.sql = str(sql)
        self.es_execute = str(es_execute)
        self.es_path = str(es_path)
        self.es_query = str(es_query).encode("utf-8")
        self.es_method = str(es_method)

    def setUp(self):
        log.info("↓------test_clear_manual_order %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_clear_manual_order %s %s开始------↓" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_clear_manual_order")
    def test_clear_manual_order(self):
        # 清理数据库数据
        if self.sql != '':
            db.connect()
            db.insert(self.sql)
            db.close()
        # 清理es数据
        if self.es_execute == 'yes':
            response = req.run_main(self.es_method, self.es_path, self.es_query)
            if '"deleted": 0' in response.text:
                log.error('%s未成功清理es数据' % self.case_name)
        self.assertEqual('清理无校验', '清理无校验')


if __name__ == '__main__':
    unittest.main()
