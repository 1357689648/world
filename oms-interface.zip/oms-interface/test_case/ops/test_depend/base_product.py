# -*- coding: utf-8 -*-

'''
@Time    : 2020/12/23 19:39
@Author  : Jia Lu Yun
'''

from common.base.read_excel import ReadExcel
from common.base.get_url_params import GeturlParams
from common.base.config_http import RunMain
from common.utils.interface_depend import InterfaceDepend
from common.base.config_log import Log
from common.base.get_mysql import GetMySql


logger = Log().run()
get_mysql = GetMySql()


class BaseProduct(object):
    def __init__(self):
        self.base_data_excel = ''
        self.case_id = ''
        self.case_name = ''
        self.execute = ''
        self.path = ''
        self.query = ''
        self.method = ''
        self.status_code = ''
        self.response = ''
        self.sql = ''
        self.depend = ''

    def create_base_product(self):
        self.base_data_excel = ReadExcel().get_xls('ops/baseProduct.xlsx', 'create')
        get_mysql.connect()
        for case in self.base_data_excel:
            self.case_id = str(case[0])
            self.case_name = str(case[1])
            self.execute = str(case[2])
            self.path = str(case[3])
            self.query = str(case[4])
            self.method = str(case[5])
            self.status_code = int(case[6])
            self.response = str(case[7])
            self.sql = str(case[8])
            self.depend = str(case[9])
            try:
                self.interface_execute()
            except BaseException as error:
                logger.error(error)
        get_mysql.close()

    # 执行单行用例
    def interface_execute(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            logger.info('****** ops/baseProduct.xlsx/create:' + self.case_name)
            if self.depend != '':
                self.query = InterfaceDepend().update_query_or_path(self.query, self.depend, self.base_data_excel)
                self.path = InterfaceDepend().update_query_or_path(self.path, self.depend, self.base_data_excel)
            url = GeturlParams().get_url() + self.path
            if self.path != '':
                response = RunMain().run_main(self.method, url, self.query.encode("utf-8"))
                try:
                    assert response.status_code == self.status_code
                except BaseException as error:
                    logger.error('status_code: ' + response.status_code + ' not equal ' + self.status_code)
                    logger.debug('url:' + url)
                    logger.debug('query:' + self.query)
                    logger.error(error)
                try:
                    assert self.response in response.text
                except BaseException as error:
                    logger.error('response.text:' + self.response + ' not in ' + response.text)
                    logger.debug('url:' + url)
                    logger.debug('query:' + self.query)
                    logger.error(error)
            if self.sql != '':
                get_mysql.update(self.sql)

    # delete sql清理基础数据
    def clear_base_product(self):
        self.base_data_excel = ReadExcel().get_xls('ops/baseProduct.xlsx', 'clearSql')
        get_mysql.connect()
        for case in self.base_data_excel:
            self.case_name = case[1]
            self.execute = case[2]
            self.sql = case[8]
            if self.sql != '' and self.execute == 'yes':
                logger.info("****** ops/baseProduct.xlsx/clearSql:" + self.case_name)
                try:
                    get_mysql.delete(self.sql)
                except BaseException as error:
                    logger.error(error)
                    print(error)
        get_mysql.close()


if __name__ == '__main__':
    # BaseProduct().create_base_product()
    BaseProduct().clear_base_product()
