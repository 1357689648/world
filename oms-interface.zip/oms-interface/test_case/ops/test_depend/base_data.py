# -*- coding: utf-8 -*-

'''
@Time    : 2020/12/21 10:37
@Author  : Jia Lu Yun
'''

from common.base.read_excel import ReadExcel
from common.base.get_url_params import GeturlParams
from common.base.config_http import RunMain
from common.utils.interface_depend import InterfaceDepend
from common.base.config_log import Log
from common.base.get_mysql import GetMySql
import time
from common.base.redis_hander import RedisHander
from common.utils.read_config import ReadConfig


logger = Log().run()
get_mysql = GetMySql()
rc = RedisHander()
config = ReadConfig()


class BaseData(object):
    def __init__(self):
        self.base_data_excel = ''
        self.case_id = ''
        self.case_name = ''
        self.execute = ''
        self.path = ''
        self.query = ''
        self.method = ''
        self.status_code = ''
        self.response = ''
        self.sql = ''
        self.depend = ''

    # 创建基础数据
    def create_base_data(self, owner_name, shop_name, warehouse_name, logistic_name, logistic_template_name, logistic_strategy_name):
        self.base_data_excel = ReadExcel().get_xls('ops/baseData.xlsx', 'create')
        for i in range(len(self.base_data_excel)):
            self.base_data_excel[i][3] = self.replace_base_data(self.base_data_excel[i][3], owner_name, shop_name, warehouse_name, logistic_name, logistic_template_name, logistic_strategy_name)
            self.base_data_excel[i][4] = self.replace_base_data(self.base_data_excel[i][4], owner_name, shop_name, warehouse_name, logistic_name, logistic_template_name, logistic_strategy_name)
            self.base_data_excel[i][8] = self.replace_base_data(self.base_data_excel[i][8], owner_name, shop_name, warehouse_name, logistic_name, logistic_template_name, logistic_strategy_name)
        get_mysql.connect()
        for case in self.base_data_excel:
            self.case_id = str(case[0])
            self.case_name = str(case[1])
            self.execute = str(case[2])
            self.path = str(case[3])
            self.query = str(case[4])
            self.method = str(case[5])
            self.status_code = int(case[6])
            self.response = str(case[7])
            self.sql = str(case[8])
            self.depend = str(case[9])
            try:
                self.interface_execute()
            except BaseException as error:
                print(error)
                logger.error(error)
        get_mysql.close()

    # 替换param中的货主名称、仓库名称等数据，实现指定参数操作
    def replace_base_data(self, param, owner_name, shop_name, warehouse_name, logistic_name, logistic_template_name, logistic_strategy_name):
        param = param.replace("auto_owner_name", owner_name)
        param = param.replace("auto_shop_name", shop_name)
        param = param.replace("auto_warehouse_name", warehouse_name)
        param = param.replace("auto_logistic_name", logistic_name)
        param = param.replace("auto_logistic_template_name", logistic_template_name)
        param = param.replace("auto_logistic_strategy_name", logistic_strategy_name)
        return param

    # 执行单行用例
    def interface_execute(self):
        if self.execute == 'no':
            # 开始执行依赖接口，清理当前登录用户的权限缓存
            employee_id = config.get_header('employeeid')
            rc.conn_redis().delete(employee_id)
            return
        elif self.execute == 'yes':
            logger.info('****** ops/baseData.xlsx/create:' + self.case_name)
            if self.depend != '':
                self.query = InterfaceDepend().update_query_or_path(self.query, self.depend, self.base_data_excel)
                self.path = InterfaceDepend().update_query_or_path(self.path, self.depend, self.base_data_excel)
            url = GeturlParams().get_url() + self.path
            if self.path != '':
                response = RunMain().run_main(self.method, url, self.query.encode("utf-8"))
                try:
                    assert response.status_code == self.status_code
                except BaseException as error:
                    logger.error('status_code: ' + response.status_code + ' not equal ' + self.status_code)
                    logger.debug('url:' + url)
                    logger.debug('query:' + self.query)
                    logger.error(error)
                try:
                    assert self.response in response.text
                except BaseException as error:
                    logger.error('response.text:' + self.response + ' not in ' + response.text)
                    logger.debug('url:' + url)
                    logger.debug('query:' + self.query)
                    logger.error(error)

            if self.sql != '':
                time.sleep(0.3)
                get_mysql.update(self.sql)

    # delete sql清理基础数据
    def clear_base_data(self, owner_name, shop_name, warehouse_name, logistic_name, logistic_template_name, logistic_strategy_name):
        self.base_data_excel = ReadExcel().get_xls('ops/baseData.xlsx', 'clearSql')
        get_mysql.connect()
        for case in self.base_data_excel:
            self.case_name = case[1]
            self.execute = case[2]
            self.sql = case[8]
            if self.sql != '' and self.execute == 'yes':
                logger.info("****** ops/baseData.xlsx/clearSql:" + self.case_name)
                self.sql = self.replace_base_data(self.sql, owner_name, shop_name, warehouse_name, logistic_name,
                                                  logistic_template_name, logistic_strategy_name)
                try:
                    get_mysql.delete(self.sql)
                except BaseException as error:
                    logger.error(error)
                    print(error)
        get_mysql.close()


if __name__ == '__main__':
    BaseData().create_base_data("auto货主", "auto店铺", "auto仓库", "auto物流", "auto物流模板", "auto物流策略")
    # BaseData().clear_base_data("auto货主", "auto店铺", "auto仓库", "auto物流", "auto物流模板", "auto物流策略")
    pass


