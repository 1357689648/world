# -*- coding: utf-8 -*-

'''
@Time    : 2020/7/17 13:48
@Author  : Jia Lu Yun
'''
import unittest
import paramunittest
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.base.get_url_params import GeturlParams
from common.base.get_mysql import GetMySql

logger = Log().run()
base_url = GeturlParams()
req = RunMain()
db = GetMySql()
read_excel = ReadExcel()

# 执行清理sql
clear_sql = read_excel.get_xls('orderBaseData.xlsx', 'clearSql')
@paramunittest.parametrized(*clear_sql)
class ClearSql(unittest.TestCase):
    def setParameters(self, case_name, sql):
        self.case_name = str(case_name)
        self.sql = str(sql)

    def setUp(self):
        logger.info("↓------test_clear_sql %s开始------↓" % self.case_name)

    def tearDown(self):
        logger.info("↑------test_clear_sql %s完成------↑" % self.case_name)

    # @unittest.skip("不执行test_clear_sql")
    def test_clear_sql(self):
        # 执行sql
        db.connect()
        db.update(self.sql)
        db.close()
        self.assertEqual('清理无校验', '清理无校验')


if __name__ == '__main__':
    unittest.main()
