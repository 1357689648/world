# -*- coding: utf-8 -*-

'''
@Time    : 2020/7/17 13:47
@Author  : Jia Lu Yun
'''

import unittest
import paramunittest
from common.base.read_excel import ReadExcel
from common.base.config_http import RunMain
from common.base.config_log import Log
from common.base.get_url_params import GeturlParams
from common.base.get_mysql import GetMySql
from common.utils.interface_depend import InterfaceDepend

log = Log().run()
base_url = GeturlParams()
req = RunMain()
db = GetMySql()
read_excel = ReadExcel()
interface_depend = InterfaceDepend()


# 创建店铺，准备店铺数据
create_shop = read_excel.get_xls('orderBaseData.xlsx', 'createShop')
@paramunittest.parametrized(*create_shop)
class ACreateShop(unittest.TestCase):
    def setParameters(self, case_name, path, query, method, status_code, response, sql):
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)
        self.sql = str(sql)

    def setUp(self):
        log.info("↓------test_create_shop %s开始------↓" % self.case_name)

    def tearDown(self):
        log.info("↑------test_create_shop %s完成------↑" % self.case_name)

    # @unittest.skip("不执行test_create_shop")
    def test_create_shop(self):
        url = base_url.get_url() + self.path
        response = req.run_main(self.method, url, self.query)
        self.assertEqual(response.status_code, self.status_code)
        self.assertIn(self.response, response.text)
        # sql不为空，需执行
        if self.sql != '':
            # 执行sql
            db.connect()
            db.update(self.sql)
            db.close()


# 创建货主，准备货主数据
create_owner = read_excel.get_xls('orderBaseData.xlsx', 'createOwner')
@paramunittest.parametrized(*create_owner)
class BCreateOwner(unittest.TestCase):
    def setParameters(self, case_name, path, query, method, status_code, response, sql):
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)
        self.sql = str(sql)

    def setUp(self):
        log.info("↓------test_create_owner %s开始------↓" % self.case_name)

    def tearDown(self):
        log.info("↑------test_create_owner %s完成------↑" % self.case_name)

    # @unittest.skip("不执行test_create_owner")
    def test_create_owner(self):
        url = base_url.get_url() + self.path
        response = req.run_main(self.method, url, self.query)
        self.assertEqual(response.status_code, self.status_code)
        self.assertIn(self.response, response.text)
        # sql不为空，需执行
        if self.sql != '':
            db.connect()
            db.update(self.sql)
            db.close()


# 创建仓库，准备仓库数据
create_warehouse = read_excel.get_xls('orderBaseData.xlsx', 'createWarehouse')
@paramunittest.parametrized(*create_warehouse)
class CCreateWarehouse(unittest.TestCase):
    def setParameters(self, case_name, path, query, method, status_code, response, sql):
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = int(status_code)
        self.response = str(response)
        self.sql = str(sql)

    def setUp(self):
        log.info("↓------test_create_warehouse %s开始------↓" % self.case_name)

    def tearDown(self):
        log.info("↑------test_create_warehouse %s完成------↑" % self.case_name)

    # @unittest.skip("不执行test_create_warehouse")
    def test_create_warehouse(self):
        url = base_url.get_url() + self.path
        response = req.run_main(self.method, url, self.query)
        self.assertEqual(response.status_code, self.status_code)
        self.assertIn(self.response, response.text)
        # sql不为空，需执行
        if self.sql != '':
            db.connect()
            db.update(self.sql)
            db.close()


# 用户授权仓库、店铺、货主
authorize = read_excel.get_xls('orderBaseData.xlsx', 'authorize')
@paramunittest.parametrized(*authorize)
class DAuthorize(unittest.TestCase):
    def setParameters(self, case_name, sql):
        self.case_name = str(case_name)
        self.sql = str(sql)

    def setUp(self):
        log.info("↓------test_authorize %s开始------↓" % self.case_name)

    def tearDown(self):
        log.info("↑------test_authorize %s完成------↑" % self.case_name)

    # @unittest.skip("不执行test_authorize")
    def test_authorize(self):
        # 执行sql
        db.connect()
        db.update(self.sql)
        db.close()
        self.assertEqual('授权无校验', '授权无校验')


# 货主绑定店铺
owner_bind_shop = read_excel.get_xls('orderBaseData.xlsx', 'ownerBindShop')
@paramunittest.parametrized(*owner_bind_shop)
class EOwnerBindShop(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_owner_bind_shop %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_owner_bind_shop %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_owner_bind_shop")
    def test_owner_bind_shop(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, owner_bind_shop)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 货主绑定仓库
owner_bind_warehouse = read_excel.get_xls('orderBaseData.xlsx', 'ownerBindWarehouse')
@paramunittest.parametrized(*owner_bind_warehouse)
class FOwnerBindWarehouse(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_owner_bind_warehouse %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_owner_bind_warehouse %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_owner_bind_warehouse")
    def test_owner_bind_warehouse(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, owner_bind_warehouse)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 创建物流
create_logistics = read_excel.get_xls('orderBaseData.xlsx', 'createLogistics')
@paramunittest.parametrized(*create_logistics)
class GCreateLogistics(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_create_logistics %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_create_logistics %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_create_logistics")
    def test_create_logistics(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, create_logistics)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 店铺绑定物流
shop_bind_logistics = read_excel.get_xls('orderBaseData.xlsx', 'shopBindLogistics')
@paramunittest.parametrized(*shop_bind_logistics)
class HShopBindLogistics(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_shop_bind_logistics %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_shop_bind_logistics %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_shop_bind_logistics")
    def test_shop_bind_logistics(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, shop_bind_logistics)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 店铺绑定仓库
shop_bind_warehouse = read_excel.get_xls('orderBaseData.xlsx', 'shopBindWarehouse')
@paramunittest.parametrized(*shop_bind_warehouse)
class IShopBindWarehouse(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_shop_bind_warehouse %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_shop_bind_warehouse %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_shop_bind_warehouse")
    def test_shop_bind_warehouse(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, shop_bind_warehouse)
            url = base_url.get_url() + self.path
            print(self.query)
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 仓库绑定物流
warehouse_bind_logistics = read_excel.get_xls('orderBaseData.xlsx', 'warehouseBindLogistics')
@paramunittest.parametrized(*warehouse_bind_logistics)
class JWarehouseBindLogistics(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_warehouse_bind_logistics %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_warehouse_bind_logistics %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_warehouse_bind_logistics")
    def test_warehouse_bind_logistics(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, warehouse_bind_logistics)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 仓库发货范围
warehouse_area = read_excel.get_xls('orderBaseData.xlsx', 'warehouseArea')
@paramunittest.parametrized(*warehouse_area)
class KWarehouseArea(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_warehouse_area %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_warehouse_area %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_warehouse_area")
    def test_warehouse_area(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, warehouse_area)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 创建物流模板
create_logistics_template = read_excel.get_xls('orderBaseData.xlsx', 'createLogisticsTemplate')
@paramunittest.parametrized(*create_logistics_template)
class LCreateLogisticsTemplate(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_create_logistics_template %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_create_logistics_template %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_create_logistics_template")
    def test_create_logistics_template(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, create_logistics_template)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.update(self.sql)
                db.close()


# 物流模板发货范围
logistics_area = read_excel.get_xls('orderBaseData.xlsx', 'logisticsArea')
@paramunittest.parametrized(*logistics_area)
class MLogisticsArea(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_logistics_area %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_logistics_area %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_logistics_area")
    def test_logistics_area(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 修改发货范围，发货范围从数据中取，替换body里的发货范围（指定替换词为jlyareaCode）
            if self.sql != '':
                db.connect()
                area_code = db.select(self.sql)
                self.query = (self.query.decode()).replace('jlyareaCode', area_code[0][0])
                db.close()
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query, self.depend, logistics_area)
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query.encode("utf-8"))
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)


# 新建货品、组合装、单品库存、组合装库存
create_product_stock = read_excel.get_xls('orderBaseData.xlsx', 'createProductStock')
@paramunittest.parametrized(*create_product_stock)
class NCreateProduct(unittest.TestCase):
    def setParameters(self, case_id, case_name, execute, path, query, method, status_code, response, sql, depend):
        self.case_id = str(case_id)
        self.case_name = str(case_name)
        self.execute = str(execute)
        self.path = str(path)
        self.query = str(query).encode("utf-8")
        self.method = str(method)
        self.status_code = status_code
        self.response = str(response)
        self.sql = str(sql)
        self.depend = str(depend)

    def setUp(self):
        log.info("↓------test_create_product_stock %s %s开始------↓" % (self.case_id, self.case_name))

    def tearDown(self):
        log.info("↑------test_create_product_stock %s %s完成------↑" % (self.case_id, self.case_name))

    # @unittest.skip("不执行test_create_product_stock")
    def test_create_product_stock(self):
        if self.execute == 'no':
            return
        elif self.execute == 'yes':
            # 若存在依赖信息，根据依赖替换query值
            if self.depend != '':
                self.query = interface_depend.update_query(self.query.decode(), self.depend, create_product_stock)
                self.query = self.query.encode("utf-8")
            url = base_url.get_url() + self.path
            response = req.run_main(self.method, url, self.query)
            self.assertEqual(response.status_code, self.status_code)
            self.assertIn(self.response, response.text)
            # sql不为空，需执行
            if self.sql != '':
                db.connect()
                db.insert(self.sql)
                db.close()


if __name__ == '__main__':
    unittest.main()
