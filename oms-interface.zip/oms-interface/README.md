# jbs_oms
##### python规范建议参考：https://www.runoob.com/w3cnote/google-python-styleguide.html
# 目录结构

## bin: 项目执行入口，执行用例信息和启用脚本
  ### caselist.txt：
    配置将要执行testCase目录下的哪些用例文件，前加#代表不进行执行，当项目过于庞大，用例足够多的时候，我们可以通过这个开关，来确定本次执行哪些接口的哪些用例。
  ### run_all.py:
    执行接口自动化，项目工程部署完毕后直接运行该文件即可

## common：存放公共文件
   ### config：
   #### config_email.py：
    配置发送邮件的主题、正文等，将测试报告发送并抄送到相关人邮箱的逻辑 (outlook)
  #### config_email_smtp.py：
    配置发送邮件的主题、正文等，将测试报告发送并抄送到相关人邮箱的逻辑 (smtp)
  #### config_http.py：
    通过get、post、put、delete等方法来进行http请求，并拿到请求响应
  #### config_log.py：
    打印生成日志
  #### get_elasticsearch.py:
     读取ES，获取ES数据
  #### get_mysql.py：
    读取数据库，获取数据库数据   
  ### report：
  #### HTMLTestRunner.py：
    生成测试报告文件
  ### utils：
  #### cmp_json.py:
    去除无用的json数据
  #### format_response.py:
    格式化response信息，移除无用json
  #### get_path_info.py:
    获取项目路径   
  #### get_url_params.py:
    获取接口的URL、参数、method
  #### read_config.py：
    读取配置文件的方法，并返回文件中内容   
  #### read_excel.py：
    读取Excel文件   

## config:
  ### config.ini：
    数据库、邮箱、接口等的配置项，用于方便的调用读取

## log：   
    logs.txt:存放日志文件   
   
## report:   
    report.html:测试报告文件   
  
## test_case：
    测试用例
 
## test_file/case:
    case.xlsx:存放测试数据
